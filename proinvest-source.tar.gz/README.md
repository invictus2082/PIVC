Development moved to https://gitlab.com/blacknet-ninja

https://proinvest.org/ aims to continue on ProInvest chain.
